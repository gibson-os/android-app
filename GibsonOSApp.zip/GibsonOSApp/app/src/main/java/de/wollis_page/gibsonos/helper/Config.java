package de.wollis_page.gibsonos.helper;

public class Config {
    public static final String LOG_TAG = "gibsonos";
}
